# Design System: High-Energy Gamified Portfolio

## 1. Overview & Creative North Star: "The Kinetic Anti-Hero"

This design system is not a template; it is a controlled explosion. The **Creative North Star** for this system is **"The Kinetic Anti-Hero."** It rejects the sterile, "safe" layout patterns of modern SaaS in favor of a dynamic, fourth-wall-breaking editorial experience. 

We achieve a high-end feel by balancing chaos with precision. While the aesthetics draw from gritty comic-book tropes—diagonal slashes, distressed textures, and bold shadows—the underlying structure is governed by a rigorous typographic scale and intentional tonal layering. By avoiding "simple boxes" and standard borders, we create a layout that feels alive, reactionary, and premium.

---

## 2. Colors & Surface Philosophy

The palette is aggressive, high-contrast, and deeply layered. We utilize a "Carbon-and-Crimson" foundation to drive energy.

### Color Tokens
- **Primary (`#BE1E2D` / `primary_container`):** The "Hero" red. Used for high-impact accents, primary CTAs, and diagonal slashes.
- **Surface (`#131313` / `surface`):** The "Carbon" base. A deep, near-black that provides the canvas for high-energy elements.
- **On-Surface (`#e5e2e1` / `on_surface`):** High-contrast off-white to ensure readability against dark backgrounds.

### The Rules of Engagement
*   **The "No-Line" Rule:** Standard 1px borders are strictly prohibited for sectioning. Separation is achieved through **Surface Hierarchy** (e.g., placing a `surface_container_high` element atop a `surface_dim` background) or through **Diagonal Slashes**—using CSS masks or clip-paths to create aggressive, non-linear transitions between sections.
*   **The "Glass & Texture" Rule:** To avoid a flat, "cheap" look, use `surface_container_highest` with a `backdrop-blur` (12px–20px) for floating overlays. Apply a subtle "Carbon Fiber" grain texture (noise overlay at 3% opacity) across the entire background to provide tactile depth.
*   **Signature Gradients:** For primary buttons and "Epic" headers, use a linear gradient from `primary_container` (#BE1E2D) to `on_primary_fixed_variant` (#930019) at a 135-degree angle. This prevents the red from feeling "flat" and adds a metallic, automotive sheen.

---

## 3. Typography: The Editorial Voice

Hierarchy is the difference between a "comic book" and a "mess." We use a dual-personality typeface system.

*   **Display & Headlines (Epilogue):** Set with tight letter-spacing (-0.04em) and heavy weights. For a "distressed" look, use CSS `text-shadow` to create a slight "ink-bleed" or offset "misprint" effect in `primary` colors.
*   **Body (Inter):** The "Grounding" element. While the headlines are chaotic, the body text must be surgically clean. Use `body-md` (0.875rem) with generous line-height (1.6) to ensure the unconventional layout remains readable.
*   **Labels (Space Grotesk):** Used for "metadata" or "stats" in gamified components. This mono-spaced influence adds a technical, tactical feel to the portfolio's "loadout" screens.

---

## 4. Elevation, Depth & Shadow

We move away from Material Design's "lighting from above" to a "cinematic, high-contrast" model.

*   **The Layering Principle:** Depth is achieved by "stacking." 
    *   *Level 0:* `surface_container_lowest` (Background)
    *   *Level 1:* `surface_container_low` (Sections/Slashes)
    *   *Level 2:* `surface_container_high` (Interactive Cards)
*   **Hard-Edge Ambient Shadows:** Unlike soft, "airy" UI, this system uses **Bold Shadows.** Use the `primary_fixed_variant` color at 40% opacity with a *low* blur (4px) and *high* offset (8px, 8px) to create a "pop-art" lift.
*   **The "Ghost Border" Fallback:** If a container needs definition, use `outline_variant` at 15% opacity. It should feel like a faint scuff on carbon fiber, not a structural line.
*   **Fourth-Wall Parallax:** Elements should react to the cursor. Use physics-based "tilt" effects on cards where the element leans *away* from the mouse, as if the user is physically pushing the UI.

---

## 5. Components

### Buttons: The "Trigger"
*   **Primary:** Sharp 0px corners. Background: `primary_container`. Hover state: A "glitch" animation where the button shifts 4px and changes to `inverse_primary`.
*   **Tertiary:** Text-only in `on_surface`, but underlined with a 4px diagonal "slash" that expands on hover.

### Tooltips: The "Speech Bubble"
*   Break the grid. Tooltips are styled as **Comic-Book Speech Bubbles**. Background: `on_surface_variant`, Text: `on_secondary_fixed`. Use a sharp, triangular pointer and a thick `primary` shadow.

### Cards: The "Intel Dossier"
*   No rectangles. Use `clip-path` to "dog-ear" one corner or create a diagonal slant at the bottom.
*   Instead of dividers, use **Vertical White Space** or a 2px-high `primary` diagonal slash to separate header text from body content.

### Inputs: The "Terminal"
*   Fields are `surface_container_lowest`. On focus, the background "ignites" with a subtle `primary` glow and the label performs a "snappy" spring-physics pop-out.

### New Component: The "Action Slasher"
*   A full-width layout divider that is a literal diagonal slash. Content inside follows the slant, creating a sense of forward momentum and breaking the traditional horizontal scroll.

---

## 6. Do’s and Don’ts

### Do:
*   **Embrace Asymmetry:** If a layout feels too balanced, tilt a container by 1–2 degrees.
*   **Snappy Motion:** Use `cubic-bezier(0.175, 0.885, 0.32, 1.275)` for "overshoot" animations that feel explosive yet controlled.
*   **Layer with Intent:** Treat every image as if it's being "slashed" onto the page—use overlapping elements where text partially covers an image.

### Don’t:
*   **Don't use Rounded Corners:** This system is `0px` everywhere. Sharp edges convey danger and precision.
*   **Don't use Center-Alignment:** It feels too formal. Lean into left-aligned "rugged" typography or extreme right-aligned "tactical" labels.
*   **Don't Fade In:** Elements should "shatter" or "slide" into view. Fading is for quiet designs; this system shouts.